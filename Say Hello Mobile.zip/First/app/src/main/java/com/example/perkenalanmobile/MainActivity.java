package com.example.perkenalanmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

//Created 26-03-2020

public class MainActivity extends AppCompatActivity {
Button buy;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (getSupportActionBar() != null){
            getSupportActionBar().setTitle("Google Pixel");
        }

        buy = findViewById(R.id.beli);
        buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Harap bersabar \nSistem Dalam pengembangan :)",Toast.LENGTH_LONG).show();
            }
        });


    }
}
